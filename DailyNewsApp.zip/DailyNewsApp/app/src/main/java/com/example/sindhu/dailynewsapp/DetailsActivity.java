
package com.example.sindhu.dailynewsapp;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.example.sindhu.dailynewsapp.adapters.NewsAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DetailsActivity extends AppCompatActivity {
    String nurl1="https://newsapi.org/v2/everything?sources=";
    String nurl_end="&pagesize=100&apiKey=d5c4f8cf60b84d099fa7e72d96ab9edb";
    RecyclerView rv;
    NewsViewModel viewModel;
    List<NewsModel> models;
    LinearLayout linearLayout,progressBar;
    String nname;
    private String fav="fav";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        rv=findViewById(R.id.details_recyclerview);
        progressBar=findViewById(R.id.progress);
        models=new ArrayList<>();
        viewModel= ViewModelProviders.of(this).get(NewsViewModel.class);
        linearLayout=findViewById(R.id.layout1);
        nname=getIntent().getStringExtra(getResources().getString(R.string.detail_intent));
        initialSetup();
    }
    public void initialSetup(){
        if(nname.equals(fav)){
            showFavourites();
        }else {
            ConnectivityManager connectivityManager
                    = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                    new NewsDisplayTask().execute(nurl1
                            + nname + nurl_end);
            } else {
                Snackbar snackbar = Snackbar.make(linearLayout, R.string.no_internet
                        , Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        }
        setTitle(nname);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new NewsAdapter(this,models));
    }

    public void showFavourites() {
        viewModel.getAllFavArticle().observe(this, new Observer<List<NewsModel>>() {
            @Override
            public void onChanged(@Nullable List<NewsModel> newsModels) {
                if(newsModels.size()==0){
                    progressBar.setVisibility(View.GONE);
                    Snackbar snackbar=Snackbar.make(linearLayout,
                            R.string.no_favorite,Snackbar.LENGTH_LONG);
                    snackbar.show();
                }else {
                    progressBar.setVisibility(View.GONE);
                    rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    rv.setAdapter(new NewsAdapter(DetailsActivity.this,newsModels));
                }
            }
        });

    }

    public class NewsDisplayTask extends AsyncTask<String,Void,String>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url=new URL(strings[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                InputStream inputStream=urlConnection.getInputStream();
                Scanner s=new Scanner(inputStream);
                s.useDelimiter("\\A");
                if(s.hasNext()){
                    return s.next();
                }
                else {
                    return  null;
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    JSONArray articles=jsonObject.getJSONArray(getString(R.string.article));
                    for (int i=0;i<articles.length();i++){
                        JSONObject ob=articles.getJSONObject(i);
                        String title=ob.getString(getString(R.string.title));
                        String img=ob.getString(getString(R.string.image));
                        String desc=ob.getString(getString(R.string.desc));
                        String pub=ob.getString(getString(R.string.published));
                        models.add(new NewsModel(pub,title,img,desc));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
        }
    }
}
